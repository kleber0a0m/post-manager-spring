package br.edu.ifsuldeminas.mch.si.webii.postmanager.spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PostmanagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
