package br.edu.ifsuldeminas.mch.si.webii.postmanager.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PostmanagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(PostmanagerApplication.class, args);
	}

}
